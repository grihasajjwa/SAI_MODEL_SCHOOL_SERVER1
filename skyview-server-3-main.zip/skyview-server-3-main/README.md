MONGODB_URI=mongodb+srv://nsutradharcob:Skyview123@cluster0.lqkza.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0
PORT=5000
JWT_SECRET=skyview_school_secret_key
NODE_ENV=development
